﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class damagePlayer : MonoBehaviour {

    public int playerHealth;
    int damage;
     void Start()
    {
       
    }
}
